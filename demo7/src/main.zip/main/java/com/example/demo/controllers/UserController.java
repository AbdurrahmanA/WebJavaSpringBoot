package com.example.demo.controllers;

import com.example.demo.data.LoginForm;
import com.example.demo.data.UserEntity;
import com.example.demo.services.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    // Kullanıcıları listele
    @GetMapping
    public String listUsers(Model model) {
        model.addAttribute("users", userService.getAllUsers());
        return "listUser";
    }

    // Yeni kullanıcı formu
    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("user", new UserEntity());
        return "addUser";
    }

    // Yeni kullanıcı ekle
    @PostMapping("/add")
    public String addUser(@ModelAttribute("user") @Valid UserEntity user, BindingResult result) {
        if (result.hasErrors()) {
            return "addUser";
        }
        userService.createUser(user);
        return "redirect:/users";
    }

    // Kullanıcı düzenleme formu
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Integer id, Model model) {
        UserEntity user = userService.getUserById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid user ID:" + id));
        model.addAttribute("user", user);
        return "editUser";
    }

    // Kullanıcıyı güncelle
    @PostMapping("/edit/{id}")
    public String updateUser(@PathVariable Integer id,
                             @ModelAttribute("user") @Valid UserEntity user,
                             BindingResult result) {
        if (result.hasErrors()) {
            return "editUser";
        }
        user.setId(id);
        userService.createUser(user);
        return "redirect:/users";
    }

    // Kullanıcı sil
    @GetMapping("/delete/{id}")
    public String deleteUser(@PathVariable Integer id) {
        userService.deleteUser(id);
        return "redirect:/users";
    }

    // Rol değiştirme
    @PostMapping("/changeRole")
    public String changeUserRole(@RequestParam int userId,
                                 @RequestParam String role) {
        userService.changeUserRole(userId, role);
        return "redirect:/users";
    }

    // Kayıt formu
    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("user", new UserEntity());
        return "register";
    }

    // Kayıt işlemi
    @PostMapping("/register")
    public String registerUser(@ModelAttribute("user") @Valid UserEntity user,
                               BindingResult result) {
        if (result.hasErrors()) {
            return "register";
        }
        user.setRole(UserEntity.Role.ROLE_LIMITED_USER);
        userService.createUser(user);  // Şifre encode ediliyor
        return "redirect:/users/login";
    }

    // Giriş formu – sadece form için
    @GetMapping("/login")
    public String showLoginForm(Model model) {
        model.addAttribute("loginForm", new LoginForm());
        return "login";  // Thymeleaf vs. login sayfası
    }


    // Çıkış işlemi (Spring Security logout ile yapılır)
    @GetMapping("/logout")
    public String logout() {
        return "redirect:/users/login?logout";
    }
}
