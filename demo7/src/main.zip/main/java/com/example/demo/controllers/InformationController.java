package com.example.demo.controllers;

import com.example.demo.data.CategoryEntity;
import com.example.demo.data.InformationEntity;
import com.example.demo.data.UserEntity;
import com.example.demo.services.CategoryService;
import com.example.demo.services.InformationService;
import com.example.demo.services.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/information")
public class InformationController {

    @Autowired
    private InformationService informationService;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private UserService userService;

    @GetMapping({"", "/"})
    public String listInformation(Model model, HttpSession session,
                                  @RequestParam(required = false) Integer categoryId,
                                  @RequestParam(required = false) String startDate,
                                  @RequestParam(required = false) String endDate) {
        UserEntity currentUser = (UserEntity) session.getAttribute("user");

        List<CategoryEntity> categories = categoryService.getAllCategories();
        model.addAttribute("categories", categories);
        model.addAttribute("categoryId", categoryId);
        model.addAttribute("startDate", startDate);
        model.addAttribute("endDate", endDate);

        List<InformationEntity> ownInfo;
        List<InformationEntity> otherInfo;

        if (currentUser == null) {
            ownInfo = Collections.emptyList();
            otherInfo = informationService.getAllInformationFiltered(categoryId, startDate, endDate);
        } else {
            ownInfo = informationService.getInformationByOwnerFiltered(currentUser.getId(), categoryId, startDate, endDate);
            otherInfo = informationService.getAllInformationFiltered(categoryId, startDate, endDate).stream()
                    .filter(i -> !i.getOwner().getId().equals(currentUser.getId()))
                    .toList();
        }

        model.addAttribute("myInformation", ownInfo);
        model.addAttribute("otherInformation", otherInfo);

        return "list";
    }


    @GetMapping("/add")
    public String addInformationForm(Model model) {
        model.addAttribute("info", new InformationEntity());
        List<CategoryEntity> categories = categoryService.getAllCategories();
        System.out.println("Kategori sayısı: " + categories.size());  // Konsola yazdır
        model.addAttribute("categories", categories);
        return "add";
    }


    @PostMapping("/add")
    public String addInformation(@Valid @ModelAttribute("info") InformationEntity info,
                                 BindingResult result,
                                 HttpSession session,
                                 Model model) {

        // Kategoriyi manuel set et (Spring otomatik bağlamayabilir)
        if (info.getCategory() != null && info.getCategory().getId() != null) {
            categoryService.getCategoryById(info.getCategory().getId()).ifPresent(info::setCategory);
        }

        // Kullanıcı oturumu al
        UserEntity currentUser = (UserEntity) session.getAttribute("user");
        if (currentUser == null) {
            return "redirect:/login"; // Oturum yoksa login'e yönlendir
        }

        info.setOwner(currentUser);

        if (result.hasErrors()) {
            model.addAttribute("categories", categoryService.getAllCategories());
            return "add";
        }

        info.setDateAdded(LocalDate.now());
        informationService.createInformation(info);
        return "redirect:/information/";
    }

    @GetMapping("/edit/{id}")
    public String editInformation(@PathVariable("id") Integer id, Model model) {
        Optional<InformationEntity> optionalInfo = informationService.getInformationById(id);
        if (optionalInfo.isPresent()) {
            model.addAttribute("info", optionalInfo.get());
            model.addAttribute("categories", categoryService.getAllCategories());
            return "edit";
        } else {
            return "redirect:/information/";
        }
    }

    @PostMapping("/edit/{id}")
    public String updateInformation(@PathVariable("id") Integer id,
                                    @Valid @ModelAttribute("info") InformationEntity info,
                                    BindingResult result,
                                    Model model) {

        if (result.hasErrors()) {
            model.addAttribute("categories", categoryService.getAllCategories());
            return "edit";
        }

        info.setId(id);

        CategoryEntity category = categoryService.getCategoryById(info.getCategory().getId())
                .orElseThrow(() -> new RuntimeException("Category not found"));

        info.setCategory(category);

        info.setDateAdded(LocalDate.now());

        informationService.createInformation(info);

        return "redirect:/information/";
    }

    // 5. Bilgi silme
    @GetMapping("/delete/{id}")
    public String deleteInformation(@PathVariable("id") Integer id) {
        informationService.getInformationById(id).ifPresent(info -> {
            informationService.deleteInformation(info.getId());
        });
        return "redirect:/information/";
    }
}
