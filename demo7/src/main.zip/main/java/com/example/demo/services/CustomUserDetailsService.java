package com.example.demo.services;

import com.example.demo.data.UserEntity;
import com.example.demo.repositories.UserEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UserEntityRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String login) throws UsernameNotFoundException {
        UserEntity user = userRepository.findByLogin(login)
                .orElseThrow(() -> new UsernameNotFoundException("Kullanıcı bulunamadı: " + login));

        return new org.springframework.security.core.userdetails.User(
                user.getLogin(),               // username
                user.getPassword(),            // password
                Collections.singleton(user.getRole().toGrantedAuthority()) // role
        );
    }
}
